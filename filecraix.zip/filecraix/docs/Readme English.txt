Filecraix README document
Developer: Ermac.
Version: 1.0
Developer website:
https://the-future.kesug.com
What is Filecraix?
Filecraix is a simple tool designed to organize and open programs from a favorites list.
Its main purpose is to provide quick access to executables you use frequently, avoiding the need to search for them every time in the file explorer.
The program was fully developed in Python and is focused on accessibility, especially for users who rely on screen readers.
What can you do with this program?
First of all, it is important to clarify that Filecraix does not optimize programs, does not modify them, and does not speed them up.
It simply allows you to save shortcuts to executables and open them in an organized way from a single place.
Any use you make of the programs you add is entirely your responsibility.
The Future disclaims any responsibility for improper or malicious use of external software added to the favorites list.
Explanations
The options will have the same names here and inside the program.
• Add program to the list: Allows you to select an executable file (.exe) and assign it a friendly name for easy identification.
• Open favorites program list: Displays the list of saved programs and allows you to launch them directly.
• Select language: Changes the interface language among the available options.
• Main menu: Contains all the main functions of the program.
• Exit: Closes the application safely.
The program plays native system sounds when starting and when closing, similar to the sounds of connecting and disconnecting a USB device.
How can I use this program?
1. 
When opening the application, the main interface will be displayed with an informational text area and the main menu.
At startup, a system sound will play indicating that the program is ready to be used.
2. 
Main menu: Press the Alt key to access the menu and navigate through the available options.
This is especially useful for users who rely on screen readers.
3. 
Add programs:
Select an executable from your system, assign it a name, and it will be saved in the favorites list for future use.
4. 
Open programs:
From the favorites list, you can select any saved program and run it directly.
5. 
Language:
You can change the program language from the corresponding menu. The selected language is automatically saved for the next time you open Filecraix.
6. 
Close the program:
When closing the application, a native system sound similar to a USB disconnection will be played.
The program will not close until the sound has finished playing, ensuring a clean and complete shutdown.
Notice
Some antivirus software may detect the program as suspicious.
This is known as a false positive, caused by the use of Python libraries and packaging techniques.
The program is completely safe and does not perform hidden actions on the system.