Documento readme do Filecraix
Desenvolvedor: Ermac.
Versão: 1.0
Site do desenvolvedor:
https://the-future.kesug.com
O que é o Filecraix?
Filecraix é uma ferramenta simples pensada para organizar e abrir programas a partir de uma lista de favoritos.
Seu objetivo principal é facilitar o acesso rápido a executáveis que você utiliza com frequência, evitando ter que procurá-los toda vez no explorador de arquivos.
O programa foi desenvolvido completamente em Python e é voltado para acessibilidade, especialmente para usuários que utilizam leitores de tela.
O que você pode fazer com este programa?
Antes de tudo, é importante esclarecer que o Filecraix não otimiza programas, não os modifica nem os acelera.
Ele simplesmente permite salvar atalhos para executáveis e abri-los de forma organizada a partir de um único lugar.
O uso que você fizer dos programas adicionados é de sua total responsabilidade.
A The Future se isenta de qualquer uso indevido ou mal-intencionado que possa ser feito com softwares externos adicionados à lista de favoritos.
Explicações
As opções terão o mesmo nome aqui e dentro do programa.
• Adicionar programa à lista: Permite selecionar um arquivo executável (.exe) e atribuir um nome amigável para identificá-lo facilmente.
• Abrir lista de programas favoritos: Exibe a lista de programas salvos e permite abri-los diretamente.
• Selecionar idioma: Altera o idioma da interface entre os disponíveis.
• Menu principal: Contém todas as funções principais do programa.
• Sair: Fecha a aplicação de forma segura.
O programa reproduz sons nativos do sistema ao iniciar e ao fechar, semelhantes aos sons de conexão e desconexão de um dispositivo USB.
Como posso utilizar este programa?
1. 
Ao abrir a aplicação, será apresentada a interface principal com uma área de texto informativa e o menu principal.
Ao iniciar, um som do sistema será reproduzido indicando que o programa está pronto para uso.
2. 
Menu principal: Pressione a tecla Alt para acessar o menu e navegar pelas opções disponíveis.
Isso é especialmente útil para quem utiliza leitores de tela.
3. 
Adicionar programas:
Selecione um executável do seu sistema, atribua um nome e ele ficará salvo na lista de favoritos para usos futuros.
4. 
Abrir programas:
A partir da lista de favoritos, você pode selecionar qualquer programa salvo e executá-lo diretamente.
5. 
Idioma:
Você pode alterar o idioma do programa pelo menu correspondente. O idioma selecionado é salvo automaticamente para a próxima vez que o Filecraix for aberto.
6. 
Fechar o programa:
Ao fechar a aplicação, um som nativo do sistema semelhante à desconexão de um USB será reproduzido.
O programa não será encerrado até que o som termine de ser reproduzido, garantindo um fechamento limpo e completo.
Aviso
É possível que alguns antivírus detectem o programa como suspeito.
Isso é conhecido como falso positivo, causado pelo uso de bibliotecas Python e técnicas de empacotamento.
O programa é totalmente seguro e não realiza ações ocultas no sistema.