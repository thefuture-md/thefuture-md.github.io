Document README de Filecraix
Développeur : Ermac.
Version : 1.0
Site web du développeur :
https://the-future.kesug.com
Qu’est-ce que Filecraix ?
Filecraix est un outil simple conçu pour organiser et ouvrir des programmes à partir d’une liste de favoris.
Son objectif principal est de faciliter l’accès rapide aux exécutables que vous utilisez fréquemment, en évitant d’avoir à les rechercher à chaque fois dans l’explorateur de fichiers.
Le programme a été entièrement développé en Python et est orienté vers l’accessibilité, en particulier pour les utilisateurs de lecteurs d’écran.
Que pouvez-vous faire avec ce programme ?
Avant toute chose, il est important de préciser que Filecraix n’optimise pas les programmes, ne les modifie pas et ne les accélère pas.
Il permet simplement d’enregistrer des raccourcis vers des exécutables et de les ouvrir de manière organisée depuis un seul endroit.
L’utilisation que vous faites des programmes ajoutés relève entièrement de votre responsabilité.
The Future décline toute responsabilité en cas d’utilisation inappropriée ou malveillante de logiciels externes ajoutés à la liste des favoris.
Explications
Les options auront le même nom ici et dans le programme.
• Ajouter un programme à la liste : Permet de sélectionner un fichier exécutable (.exe) et de lui attribuer un nom convivial pour l’identifier facilement.
• Ouvrir la liste des programmes favoris : Affiche la liste des programmes enregistrés et permet de les lancer directement.
• Sélectionner la langue : Change la langue de l’interface parmi celles disponibles.
• Menu principal : Contient toutes les fonctions principales du programme.
• Quitter : Ferme l’application en toute sécurité.
Le programme joue des sons natifs du système au démarrage et à la fermeture, similaires aux sons de connexion et de déconnexion d’un périphérique USB.
Comment puis-je utiliser ce programme ?
1. 
Lors de l’ouverture de l’application, l’interface principale s’affiche avec une zone de texte informative et le menu principal.
Au démarrage, un son du système est joué pour indiquer que le programme est prêt à être utilisé.
2. 
Menu principal : Appuyez sur la touche Alt pour accéder au menu et naviguer parmi les options disponibles.
Ceci est particulièrement utile pour les utilisateurs de lecteurs d’écran.
3. 
Ajouter des programmes :
Sélectionnez un exécutable sur votre système, attribuez-lui un nom, et il sera enregistré dans la liste des favoris pour une utilisation ultérieure.
4. 
Ouvrir des programmes :
Depuis la liste des favoris, vous pouvez sélectionner n’importe quel programme enregistré et l’exécuter directement.
5. 
Langue :
Vous pouvez changer la langue du programme depuis le menu correspondant. La langue sélectionnée est automatiquement sauvegardée pour la prochaine ouverture de Filecraix.
6. 
Fermer le programme :
Lors de la fermeture de l’application, un son natif du système similaire à la déconnexion d’un périphérique USB est joué.
Le programme ne se fermera pas tant que le son ne sera pas entièrement terminé, garantissant une fermeture propre et complète.
Avertissement
Il est possible que certains antivirus détectent le programme comme suspect.
Cela est connu sous le nom de faux positif, causé par l’utilisation de bibliothèques Python et de techniques d’empaquetage.
Le programme est totalement sûr et n’effectue aucune action cachée sur le système.