Documento readme de Filecraix
Desarrollador: Ermac.
Versión: 1.0
Sitio web del desarrollador:
https://the-future.kesug.com
¿Qué es Filecraix?
Filecraix es una herramienta simple pensada para organizar y abrir programas desde una lista de favoritos.
Su objetivo principal es facilitar el acceso rápido a ejecutables que usás con frecuencia, evitando tener que buscarlos cada vez en el explorador de archivos.
El programa fue desarrollado completamente en Python y está orientado a ser accesible, especialmente para usuarios que utilizan lectores de pantalla.
¿Qué puedes hacer con este programa?
Antes que nada, es importante aclarar que Filecraix no optimiza programas, no los modifica ni los acelera.
Simplemente te permite guardar accesos directos a ejecutables y abrirlos de forma ordenada desde un solo lugar.
El uso que hagas de los programas que agregues es tu completa responsabilidad.
Desde The Future nos desligamos de cualquier uso indebido o malintencionado que pueda hacerse con software externo añadido a la lista de favoritos.
Explicaciones
Las opciones tendrán el mismo nombre aquí y dentro del programa.
• Añadir programa a la lista: Permite seleccionar un archivo ejecutable (.exe) y asignarle un nombre amigable para identificarlo fácilmente.
• Abrir lista de programas favoritos: Muestra la lista de programas guardados y permite abrirlos directamente.
• Seleccionar idioma: Cambia el idioma de la interfaz entre los disponibles.
• Menú principal: Contiene todas las funciones principales del programa.
• Salir: Cierra la aplicación de forma segura.
El programa reproduce sonidos nativos del sistema al iniciarse y al cerrarse, similares a los sonidos de conexión y desconexión de un dispositivo USB.
¿Cómo puedo utilizar este programa?
1. 
Al abrir la aplicación, se presentará la interfaz principal con un área de texto informativa y el menú principal.
Al iniciar, se reproducirá un sonido del sistema indicando que el programa está listo para usarse.
2. 
Menú principal: Presiona la tecla Alt para acceder al menú y navegar entre las opciones disponibles.
Esto es especialmente útil si utilizás un lector de pantalla.
3. 
Añadir programas:
Seleccioná un ejecutable desde tu sistema, asignale un nombre y quedará guardado en la lista de favoritos para futuros usos.
4. 
Abrir programas:
Desde la lista de favoritos podés seleccionar cualquier programa guardado y ejecutarlo directamente.
5. 
Idioma:
Podés cambiar el idioma del programa desde el menú correspondiente. El idioma seleccionado se guarda automáticamente para la próxima vez que abras Filecraix.
6. 
Cerrar el programa:
Al cerrar la aplicación, se reproducirá un sonido nativo del sistema similar a la desconexión de un USB.
El programa no se cerrará hasta que el sonido termine de reproducirse, asegurando una salida limpia y completa.
Aviso
Es posible que algunos antivirus detecten el programa como sospechoso.
Esto se conoce como falso positivo, causado por el uso de librerías de Python y técnicas de empaquetado.
El programa es totalmente seguro y no realiza acciones ocultas en el sistema.